import React from "react";
import { useIntl } from "react-intl";
import { NavLink, Link } from "react-router-dom";
import {
  ProSidebar,
  Menu,
  MenuItem,
  SubMenu,
  SidebarHeader,
  SidebarFooter,
  SidebarContent
} from "react-pro-sidebar";
import {
  FaTachometerAlt,
  FaGem,
  FaList,
  FaGithub,
  FaRegLaughWink,
  FaHeart,FaSignOutAlt, FaUser
} from "react-icons/fa";
import "react-pro-sidebar/dist/css/styles.css";
import { useHistory, useLocation } from "react-router-dom";

const Aside = ({ rtl, toggled, handleToggleSidebar }) => {
  const intl = useIntl();
  const history = useHistory();
  const location = useLocation();

  return (
    <ProSidebar
      rtl={rtl}
      toggled={toggled}
      breakPoint="md"
      onToggle={handleToggleSidebar}
    >
      <SidebarHeader>
        <div className="sidebar-header">
          <p className="user-name text-white mb-2">Kumar Saurabh</p>
          <p className="user-email" icon={<FaSignOutAlt />}>Sign Out</p>
          <div className="d-flex justify-content-center">
            <div className="position-absolute top-0">
            <FaUser/>
            </div>

            <div className="position-absolute bottom">
              <img
                src="./assets/images/user.jpg"
                alt="User profile"
                className="user-image"
              />
            </div>

          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <Menu iconShape="circle">
          <MenuItem
            icon={<FaTachometerAlt />}
      
          >
            <NavLink exact to={"/About"}>
              {intl.formatMessage({ id: "Dashboard" })}
            </NavLink>
          </MenuItem>
        

          <SubMenu
            // suffix={<span className="badge yellow">3</span>}
            title={intl.formatMessage({ id: "Administration" })}
            icon={<FaRegLaughWink />}
            data-element={location.pathname}
          >
            <MenuItem>
              <NavLink exact to={"/about"}>
                {intl.formatMessage({ id: "Manage Users" })} 
              </NavLink>
            </MenuItem>
            <MenuItem>
              <NavLink exact to={"/Login"}>
                {intl.formatMessage({ id: "Manage Permissions" })}
              </NavLink>
            </MenuItem>
            <MenuItem>{intl.formatMessage({ id: "Manage Management" })} </MenuItem>
          </SubMenu>

          <SubMenu
            // suffix={<span className="badge yellow">3</span>}
            title={intl.formatMessage({ id: "Load & Dispatch" })}
            icon={<FaRegLaughWink />}
            data-element={location.pathname}
          >
            <MenuItem>
              <NavLink exact to={"/about"}>
                {intl.formatMessage({ id: "submenu" })} About
              </NavLink>
            </MenuItem>
            <MenuItem>
              <NavLink exact to={"/Login"}>
                {intl.formatMessage({ id: "submenu" })} Home 2
              </NavLink>
            </MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 3</MenuItem>
          </SubMenu>

     

       
          <SubMenu
            // suffix={<span className="badge yellow">3</span>}
            title={intl.formatMessage({ id: "Indent Management" })}
            icon={<FaRegLaughWink />}
            data-element={location.pathname}
          >
            <MenuItem>
              <NavLink exact to={"/about"}>
                {intl.formatMessage({ id: "submenu" })} About
              </NavLink>
            </MenuItem>
            <MenuItem>
              <NavLink exact to={"/Login"}>
                {intl.formatMessage({ id: "submenu" })} Home 2
              </NavLink>
            </MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 3</MenuItem>
          </SubMenu>

          <SubMenu
            prefix={<span className="badge gray">3</span>}
            title={intl.formatMessage({ id: "Shipment & TO" })}
            icon={<FaHeart />}
            data-element={location.pathname}
          >
            <MenuItem>
              <NavLink exact to={"/"}>
                {intl.formatMessage({ id: "submenu" })} 1 Home
              </NavLink>
            </MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 2</MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 3</MenuItem>
          </SubMenu>
          <SubMenu
            title={intl.formatMessage({ id: "Tracks & Shipment" })}
            icon={<FaList />}
          >
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 1 </MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 2 </MenuItem>
            <SubMenu title={`${intl.formatMessage({ id: "submenu" })} 3`}>
              <MenuItem>{intl.formatMessage({ id: "submenu" })} 3.1 </MenuItem>
              <MenuItem>{intl.formatMessage({ id: "submenu" })} 3.2 </MenuItem>
              <SubMenu title={`${intl.formatMessage({ id: "submenu" })} 3.3`}>
                <MenuItem>
                  {intl.formatMessage({ id: "submenu" })} 3.3.1{" "}
                </MenuItem>
                <MenuItem>
                  {intl.formatMessage({ id: "submenu" })} 3.3.2{" "}
                </MenuItem>
                <MenuItem>
                  {intl.formatMessage({ id: "submenu" })} 3.3.3{" "}
                </MenuItem>
              </SubMenu>
            </SubMenu>
          </SubMenu>

          <SubMenu
            prefix={<span className="badge gray">3</span>}
            title={intl.formatMessage({ id: "ASN" })}
            icon={<FaHeart />}
            data-element={location.pathname}
          >
            <MenuItem>
              <NavLink exact to={"/"}>
                {intl.formatMessage({ id: "submenu" })} 1 Home
              </NavLink>
            </MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 2</MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 3</MenuItem>
          </SubMenu>


          <SubMenu
            prefix={<span className="badge gray">3</span>}
            title={intl.formatMessage({ id: "FBN" })}
            icon={<FaHeart />}
            data-element={location.pathname}
          >
            <MenuItem>
              <NavLink exact to={"/"}>
                {intl.formatMessage({ id: "submenu" })} 1 Home
              </NavLink>
            </MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 2</MenuItem>
            <MenuItem>{intl.formatMessage({ id: "submenu" })} 3</MenuItem>
          </SubMenu>




          <MenuItem icon={<FaGem />}>
            {" "}
            {intl.formatMessage({ id: "Settings" })}
          </MenuItem>

        </Menu>
      </SidebarContent>

      <SidebarFooter style={{ textAlign: "center" }}>
        <div
          className="sidebar-btn-wrapper"
          style={{
            padding: "20px 24px"
          }}
        >
          <a
            href="#"
            target="_blank"
            className="sidebar-btn"
            rel="noopener noreferrer"
          >
            <FaGithub />
            <span> {intl.formatMessage({ id: "TMS" })}</span>
          </a>
        </div>
      </SidebarFooter>
    </ProSidebar>
  );
};

export default Aside;
