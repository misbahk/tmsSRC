import React from "react";
import About from "./About";
import Layout from "./Layout";
import { Switch, Route } from "react-router-dom";
import Login from "./Login";
import Forgot from "./Forgot";

const Routes = () => {
  return (
    <>
      <Switch>
        <Route exact path={"/"}>
          <Login />
        </Route>
        <Route exact path={"/Layout"}>
          <Layout />
        </Route>
        <Route exact path={"/Forgot"}>
          <Forgot />
        </Route>
        <Route exact path={"/About"}>
          <About />
        </Route>
      </Switch>
    </>
  );
};

export default Routes;
