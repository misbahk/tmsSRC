import React, { useState }  from 'react';
  import { Link, useHistory } from "react-router-dom";
  import FormU from "./utilities/Forms";
  import './css/login.css';
  import loginlogo from "./assets/3sclogo.png";
  import { Card, Button, Container, Row, Col, InputGroup, Form } from "react-bootstrap";
  

const Forgot = () => {
    const history = useHistory();
    const [email, setEmail] = useState('');
    const [validate, setValidate] = useState({});

    const validateforgotPassword = () => {
        let isValid = true;
history.push("/");
        let validator = Form.validator({
            email: {
                value: email,
                isRequired: true,
                isEmail: true
            }
        });

        if (validator !== null) {
            setValidate({
                validate: validator.errors
            })

            isValid = false
        }
        return isValid;
    }

    const forgotPassword = (e) => {
        e.preventDefault();

        const validate = validateforgotPassword();

        if (validate) {
            alert('Reset password link is sent to '+email);
            setValidate({});
            setEmail('');
        }
    }

    return (
        <div className="center">
          <Container className="d-flex">
            <Row className="m-auto align-self-center">
              <Col>
                <Card style={{ width: "27rem" , border:"2px solid #d1d1d1"}}>
                  <Card.Img
                    variant="top"
                    src={loginlogo}
                    alt="loginlogo"
                    style={{
                      width: "9rem",
                      height: "9rem",
                      display: "flex",
                      alignSelf: "center",
                    }}
                  />
                  <Card.Body>
                    <p style={{color:"rgb(41 38 102)",fontSize:"18px", fontWeight:"500" }}>Welcome to 3SC TMS Solution</p>
                    <p style={{color:"#d1d1d1"}}> Forgot Password</p>
                               
                        <div className="auth-form-container text-start">
                            <form className="auth-form" method="POST" 
                            onSubmit={forgotPassword} autoComplete={'off'}>

                                <InputGroup className="mb-3">
         
         <Form.Control
           placeholder="Username"
           type="email"
           className={`form-control ${
             validate.validate && validate.validate.email
               ? "is-invalid "
               : ""
           }`}
           id="email"
           name="email"
           value={email}
         
           onChange={(e) => setEmail(e.target.value)}
         />
          <InputGroup.Text id="basic-addon1">@</InputGroup.Text>
       </InputGroup>
  
       <div className="email mb-3">
                                    <div className={`invalid-feedback text-start ${(validate.validate && validate.validate.email) ? 'd-block' : 'd-none'}`} >
                                        {(validate.validate && validate.validate.email) ? validate.validate.email[0] : ''}
                                    </div>
                                </div>
                                
                                <div className="text-center">
                                    <button type="submit" className="btn btn-primary w-100 theme-btn mx-auto">Forgot Password</button>
                                </div>
                            </form>

                            <hr />
                            <div className="auth-option text-center pt-2"><Link className="text-link" to="/" >Back to Login</Link></div>
                        </div>
                        </Card.Body>
                </Card>
              </Col>
            </Row>
          </Container>
          </div>
    );
}

export default Forgot;