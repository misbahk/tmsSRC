import { Table } from 'antd';
import React from 'react';
import Layout from './Layout';
import "antd/dist/antd.css";
const columns = [
  {
    title: 'Name',
    dataIndex: 'name',
    filters: [
      {
   
        text: 'Joe',
        value: 'Joe',
      },
      {
        text: 'Jim',
        value: 'Jim',
      },
      {
        text: 'Submenu',
        value: 'Submenu',
        children: [
          {
            text: 'Green',
            value: 'Green',
          },
          {
            text: 'Black',
            value: 'Black',
          },
        ],
      },
    ],
    // specify the condition of filtering result
    // here is that finding the name started with `value`
    onFilter: (value, record) => record.name.indexOf(value) === 0,
    sorter: (a, b) => a.name.length - b.name.length,
    sortDirections: ['descend'],
  },
  {
    title: 'Email',
    dataIndex: 'email',
    defaultSortOrder: 'descend',
    sorter: (a, b) => a.email - b.email,
  },



  {
    title: 'Location',
    dataIndex: 'location',
    filters: [
      {
        text: 'London',
        value: 'London',
      },
      {
        text: 'New York',
        value: 'New York',
      },
    ],
    onFilter: (value, record) => record.location.indexOf(value) === 0,
  },



  {
    title: 'Contact',
    dataIndex: 'contact',
    defaultSortOrder: 'descend',
    sorter: (a, b) => a.contact - b.contact,
 
  },
  {
    title: 'Professional',
    dataIndex: 'professsional',
    defaultSortOrder: 'descend',
    sorter: (a, b) => a.professsional - b.professsional,
  },
  {
    title: 'Modules',
    dataIndex: 'modules',
    defaultSortOrder: 'descend',
    sorter: (a, b) => a.modules - b.modules,

  },

];
const data = [
  {
    key: '1',
    name: 'John Brown',
    email: 'John@gmail.com',
    contact: 7656656565,
    location: 'PLSN Bangalore Branch',
    professsional:"Transporter",
    modules: "TMS"

  },
  {
    key: '2',
    name: 'Jim Green',
    email: 'John@gmail.com',
    contact: 7656656565,
    location: 'PLSN Hyderabad Branch',
    professsional:"Customer",
    modules: "TMS"
  },
  {
    key: '3',
    name: 'Joe Black',
    email: 'John@gmail.com',
    contact: 7656656565,
    location: 'PLSN Mumbai Branch',
    professsional:"Transporter",
    modules: "TMS"
  },
  {
    key: '4',
    name: 'Jim Red',
    email: 'John@gmail.com',
    contact: 7656656565,
    location: 'PLSN Delhi Branch',
    professsional:"Customer" ,
    modules: "TMS"
  },


  {
    key: '4',
    name: 'Jim Red',
    email: 'John@gmail.com',
    contact: 7656656565,
    location: 'PLSN Delhi Branch',
    professsional:"Customer" ,
    modules: "TMS"
  },

];

const onChange = (pagination, filters, sorter, extra) => {
  console.log('params', pagination, filters, sorter, extra);
};

const About = () =>{
  return(
    <Layout>
<Table columns={columns} dataSource={data} onChange={onChange} />;
    </Layout>
  )
  

}

export default About;