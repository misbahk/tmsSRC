import React, { useState }  from 'react';
  import { Link, useHistory } from "react-router-dom";
  import { useForm } from "react-hook-form";
  import { yupResolver } from "@hookform/resolvers/yup";
  import * as yup from "yup";
  import './css/login.css';
  import loginlogo from "./assets/3sclogo.png";
  import { Card, Button, Container, Row, Col, InputGroup, Form } from "react-bootstrap";
  


  const validationEmail = (e) => {
    e.preventDefault();
    window.location.href = "/Layout";
  };



  const schema = yup.object().shape({
    email: yup.string().email().required(),
    password: yup.string() 
    .required("Password is required.")
    .min(8, "Password need to has 8 letters.")
    .test("passwordRequirements", "Atleast 1 uppercase, 1 Lowercase & 1 alphanumeric character is required", (value) =>
      [/[a-z]/, /[A-Z]/, /[0-9]/, /[^a-zA-Z0-9]/].every((pattern) =>
        pattern.test(value)
      )
    )
  });
  

  const Login = () => {



    const { register, handleSubmit, formState: { errors }, reset } = useForm({
      resolver: yupResolver(schema),
    });
    const onSubmitHandler = (data) => {
      console.log({ data });
      login();
      // reset();
    };

    const history = useHistory();
  
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [remember, setRemember] = useState(false);
    const [validate, setValidate] = useState({});
    const [showPassword, setShowPassword] = useState(false);
  
    const validateLogin = () => {
      let isValid = true;
  
      let validator = FormU.validator({
        email: {
          value: email,
          isRequired: true,
          isEmail: true,
        },
        password: {
          value: password,
          isRequired: true,
          minLength: 6,
        },
      });
  
      if (validator !== null) {
        setValidate({
          validate: validator.errors,
        });
  
        isValid = false;
      }
      return isValid;
    };
  
    const login = () => {
     
      history.push("/Layout")
    };
  
    const authenticate = (e) => {
      e.preventDefault();
  
      const validate = validateLogin();
  
      if (validate) {
        setValidate({});
        setEmail("");
        setPassword("");
        alert("Successfully Login");
        login();
      }
    };
  
    const togglePassword = (e) => {
      if (showPassword) {
        setShowPassword(false);
      } else {
        setShowPassword(true);
      }
    };
  
    return (
      <>
 
        <div className="center">
          <Container className="d-flex">
            <Row className="m-auto align-self-center">
              <Col>
                <Card style={{ width: "27rem" , border:"2px solid #d1d1d1"}}>
                  <Card.Img
                    variant="top"
                    src={loginlogo}
                    alt="loginlogo"
                    style={{
                      width: "9rem",
                      height: "9rem",
                      display: "flex",
                      alignSelf: "center",
                    }}
                  />
                  <Card.Body>
                    <p style={{color:"rgb(41 38 102)",fontSize:"18px", fontWeight:"500" }}>Welcome to 3SC TMS Solution</p>
                    <p style={{color:"#d1d1d1"}}> Sign in into your account</p>
                    <div className="auth-form-container text-start">
                    <form onSubmit={handleSubmit(onSubmitHandler)}>
  


                    <InputGroup className="mb-3">
         
         <Form.Control
           {...register("email")} placeholder="email" 
           type="email" required
         />
          <InputGroup.Text id="basic-addon1">@</InputGroup.Text>
       </InputGroup>
 <p>{errors.email?.message}</p>
  <InputGroup className="mb-3">
         
         <Form.Control
          {...register("password")}
          placeholder="password"
          type="password"
          required
         />
          <InputGroup.Text id="basic-addon1">@</InputGroup.Text>
       </InputGroup>
       <p>{errors.password?.message}</p>
   
  
  
  
   
  
  
                        <div className="password mb-3">
                          
  
                          <div className="extra mt-3 row justify-content-between">
                            <div className="col-6">
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  type="checkbox"
                                  id="remember"
                                  checked={remember}
                                  onChange={(e) =>
                                    setRemember(e.currentTarget.checked)
                                  }
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor="remember"
                                >
                                  Remember me
                                </label>
                              </div>
                            </div>
                            <div className="col-6">
                              <div className="forgot-password text-end">
                                <Link to="/Forgot">
                                  Forgot password?
                                </Link>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="text-center">
                          <button  style={{backgroundColor:"#292666"}}
                            type="submit"
                            className="btn btn-primary w-100 theme-btn mx-auto"
                          >
                            Log In
                          </button>
                          
                        </div>
                      </form>
  
                      <hr />
                      <div className="auth-option text-center pt-2">
                        No Account?{" "}
                        <Link className="text-link" to="/register">
                          Sign up{" "}
                        </Link>
                      </div>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </Container>
        </div>
      </>
    
    );
  };
  
  export default Login;
  